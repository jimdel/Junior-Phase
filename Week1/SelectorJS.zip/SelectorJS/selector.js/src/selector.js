function isDescendant(parent, child) {
  var node = child.parentNode;
  while (node !== null) {
      if (node === parent) {
          return true;
      }
      node = node.parentNode;
  }
  return false;
}

var traverseDomAndCollectElements = function(matchFunc, startEl, resultSet) {
  resultSet = resultSet || [];

  if (typeof startEl === "undefined") {
    startEl = document.body;
  }
  if (matchFunc(startEl))resultSet.push(startEl);

  Array.from(startEl.children).forEach((element) => {
    traverseDomAndCollectElements(matchFunc, element, resultSet);
  });

  // traverse the DOM tree and collect matching elements in resultSet
  // use matchFunc to identify matching elements

  // YOUR CODE HERE

  return resultSet;
};


// detect and return the type of selector
// return one of these types: id, class, tag.class, tag

var selectorTypeMatcher = function(selector) {

  if (selector.indexOf('>') >= 0) {
    return 'child';
  } else if (selector.indexOf(' ') >= 0){
    return 'whitespace';
  } else if (selector.substring(0,1) === '#') {
    return 'id';
  } else if (selector.indexOf('.') >= 0) {
    if (selector.substring(0,1) === '.') {
      return 'class';
    } else {
      return 'tag.class'
    }
  } else {
    return 'tag';
  }
};


// NOTE ABOUT THE MATCH FUNCTION
// remember, the returned matchFunction takes an *element* as a
// parameter and returns true/false depending on if that element
// matches the selector.

var matchFunctionMaker = function(selector) {
  var selectorType = selectorTypeMatcher(selector);
  var matchFunction;
  if (selectorType === 'whitespace'){
    /*matchFunction = function(element){
      //console.log(element);
      let tags = selector.split(' ');
      let arr = Array.from(element.children);//$(tags[0]);
      var hasChild = false;
      let hasChildThatMatchesTag = function(childNode,tag){
        let children = Array.from(childNode.children)
        if(children.length > 0)children.forEach((grandChildNode) => {
          hasChild = hasChild || hasChildThatMatchesTag(grandChildNode,tag);
        });
        hasChild = hasChild || childNode.tagName === tags[1].toUpperCase();
      }
      hasChild = hasChildThatMatchesTag(element,tags[1]);
      return hasChild;
    }*/
    matchFunction = function(element){
      let tags = selector.split(' ');
      let matchTag = element.tagName === tags[1].toUpperCase();
      let parent = $(tags[0])[0];
      let hasParentWithTag = isDescendant(parent, element);
      return matchTag && hasParentWithTag;
    }
  }
  else if (selectorType === 'child') {
    matchFunction = function(element){
      let tags = selector.split(' > ');

      return element.tagName === tags[1].toUpperCase() && element.parentNode.tagName === tags[0].toUpperCase();
    }
  } else if (selectorType === "id") {
    matchFunction = function(element){
      return "#"+element.id === selector;
    }
    // define matchFunction for id

  } else if (selectorType === "class") {
    // define matchFunction for class
    matchFunction = function(element){
      var mySet = new Set(element.className.split(' '));
      //console.log(mySet);
      return mySet.has(selector.substring(1));
      //return "."+element.class === selector;
    }

  } else if (selectorType === "tag.class") {
    matchFunction = function(element){
      var matchingTag = element.tagName === selector.substring(0, selector.indexOf('.')).toUpperCase();

      var mySet = new Set(element.className.split(' '));
      var matchingClass = mySet.has(selector.substring(selector.indexOf('.') + 1));
      return matchingClass && matchingTag;
    }
    //

  } else if (selectorType === "tag") {
    matchFunction = function(element){
      //console.log(element.tagName);
      return element.tagName === selector.toUpperCase();

    }
    // define matchFunction for tag
    //matchFunction = function(element){
    //  return element.tag === selector;
   // }
  }
  return matchFunction;
};

var $ = function(selector) {
  var elements;
  var selectorMatchFunc = matchFunctionMaker(selector);
  elements = traverseDomAndCollectElements(selectorMatchFunc);
  //console.log(elements);
  return elements;
};
